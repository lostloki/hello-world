/// <reference path="globals/es6-promise/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="globals/knockout.mapping/index.d.ts" />
/// <reference path="globals/knockout.validation/index.d.ts" />
/// <reference path="globals/knockout/index.d.ts" />
/// <reference path="globals/require/index.d.ts" />
/// <reference path="globals/underscore/index.d.ts" />
