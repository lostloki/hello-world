﻿export class Label  {
    labelKey: string;    
    labelText: string;
    infoText: string;
    optionValue: string;
    cssClass: string;
    linkUrl: string;
}