﻿export class Price {
    productId: number; 
    productDefaultPrice: number;
    productDiscountPrice: number;
    productSuperDiscountPrice: number;
}