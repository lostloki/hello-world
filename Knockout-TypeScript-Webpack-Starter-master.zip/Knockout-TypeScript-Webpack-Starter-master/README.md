# Knockout-TypeScript-Webpack-Starter

Are you considering using KnockoutJS with TypeScript and Webpack for a single page application in an ASP.NET MVC context? Then get up to speed with this starter project.

Documentation can be found at:
https://blog.indivirtual.nl/mvc-knockout-typescript-webpack-starter-project/
